/*
 * minimp3_port.h
 *
 *  Created on: May 27, 2025
 *      Author: Ceyhun
 */

#ifndef MINIMP3_PORT_H
#define MINIMP3_PORT_H

#include "ff.h"  // FatFS
#include <stddef.h>

// Tell minimp3 NOT to include stdio.h
#define MINIMP3_FILE_IO_CUSTOM

#ifdef __cplusplus
extern "C" {
#endif

// Redefine FILE as alias to FatFS FIL
typedef FIL MP3FILE;

MP3FILE* mp3_fopen(const char *filename, const char *mode);
size_t mp3_fread(void *ptr, size_t size, size_t count, MP3FILE *stream);
int mp3_fseek(MP3FILE *stream, long offset, int origin);
int mp3_fclose(MP3FILE *stream);

#ifdef __cplusplus
}
#endif

#endif // MINIMP3_PORT_H
