#define MINIMP3_IMPLEMENTATION
#define MINIMP3_IO
#define MINIMP3_FILE_IO_CUSTOM

#include "minimp3_ex.h"
#include "minimp3_port.h"
#include "st7735.h"
#include <stdio.h>

// Global file instance (can only open one file at a time in this simple setup)
static FIL stm32_file;

MP3FILE* mp3_fopen(const char *filename, const char *mode) {
    char msg[64];
    snprintf(msg, sizeof(msg), "Try open: %s", filename);
    ST7735_WriteString(0, 80, msg, Font_7x10, ST7735_WHITE, ST7735_BLACK);

    FRESULT res = f_open(&stm32_file, filename, FA_READ);
    snprintf(msg, sizeof(msg), "f_open: %d", res);
    ST7735_WriteString(0, 90, msg, Font_7x10, ST7735_YELLOW, ST7735_BLACK);

    if (res == FR_OK)
        return (MP3FILE*)&stm32_file;

    return NULL;
}

size_t mp3_fread(void *ptr, size_t size, size_t count, MP3FILE *stream) {
    UINT br;
    FRESULT res = f_read((FIL*)stream, ptr, size * count, &br);

    char msg[32];
    snprintf(msg, sizeof(msg), "fread %u/%u", br, (unsigned)(size * count));
    ST7735_WriteString(0, 100, msg, Font_7x10, ST7735_WHITE, ST7735_BLACK);

    if (res != FR_OK) return 0;
    return br / size;
}

int mp3_fseek(MP3FILE *stream, long offset, int origin) {
    FRESULT res;
    DWORD new_pos = 0;

    switch (origin) {
        case SEEK_SET:
            new_pos = offset;
            break;
        case SEEK_CUR:
            new_pos = f_tell((FIL*)stream) + offset;
            break;
        case SEEK_END:
            new_pos = f_size((FIL*)stream) + offset;
            break;
        default:
            return -1;
    }

    res = f_lseek((FIL*)stream, new_pos);

    char msg[32];
    snprintf(msg, sizeof(msg), "fseek -> %lu: %d", new_pos, res);
    ST7735_WriteString(0, 110, msg, Font_7x10, ST7735_CYAN, ST7735_BLACK);

    return (res == FR_OK) ? 0 : -1;
}

int mp3_fclose(MP3FILE *stream) {
    return f_close((FIL*)stream);
}
